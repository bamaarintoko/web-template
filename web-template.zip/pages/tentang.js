import React, { Component } from 'react';
import { connect } from 'react-redux';
// import Layout from "../Container/Content"
import Index from "./index.js"
// function mapStateToProps(state) {
//     return {

//     };
// }

export default () => (
    <Index>
       <p>Tentang</p>
    </Index>
)

// class PageHome extends Component {
//     render() {
//         return (
//             <Index>
//                 <p>Hello Next.js</p>
//             </Index>
//         );
//     }
// }
// export default PageHome;
// export default connect(
//     mapStateToProps,
// )(PageHome);